//
//  ActantSDK.h
//  ActantSDK
//
//  Created by Vadim Shilov on 08.06.2021.
//

#import <Foundation/Foundation.h>

//! Project version number for ActantSDK.
FOUNDATION_EXPORT double ActantSDKVersionNumber;

//! Project version string for ActantSDK.
FOUNDATION_EXPORT const unsigned char ActantSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ActantSDK/PublicHeader.h>


